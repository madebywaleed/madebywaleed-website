"""LmarSys: solar inverter live monitor (Deye-based inverters).

Polls a Solarman Wi-Fi data logger over the local network (TCP 8899) with
pysolarmanv5, keeps the last known values, and serves a dashboard plus a JSON
API and a live stream.

Run:  python main.py
"""
import json
import logging
import os
import threading
import time
from collections import deque
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, Response, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _env(name, default, cast=str):
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return cast(raw.strip())
    except ValueError:
        logging.warning("Bad value %r for %s, using default %r", raw, name, default)
        return default


INVERTER_IP = _env("INVERTER_IP", "192.168.1.50")
LOGGER_SN = _env("LOGGER_SN", 0, int)
LOGGER_PORT = _env("LOGGER_PORT", 8899, int)
SLAVE_ID = _env("MODBUS_SLAVE_ID", 1, int)
POLL_INTERVAL = max(1.0, _env("POLL_INTERVAL", 3.0, float))
SOCKET_TIMEOUT = _env("SOCKET_TIMEOUT", 5, float)
HOST = _env("HOST", "0.0.0.0")
PORT = _env("PORT", 8000, int)
HISTORY_MINUTES = _env("HISTORY_MINUTES", 30, int)
BATTERY_INVERT = _env("BATTERY_POWER_INVERT", 0, int) == 1
GRID_INVERT = _env("GRID_POWER_INVERT", 0, int) == 1
DEADBAND_W = _env("IDLE_DEADBAND_W", 20, float)
TEMP_OFFSET = _env("TEMP_OFFSET", 1000, int)
# Seconds without a good read before the dashboard calls the data stale
STALE_AFTER_S = max(10.0, POLL_INTERVAL * 3)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("lmarsys")

# ---------------------------------------------------------------------------
# Register map (Modbus holding registers, function 0x03).
# EDIT HERE if your firmware uses different addresses. Use /api/raw to check.
#   name: (address, scale, signed)
# ---------------------------------------------------------------------------
# Two known register layouts for Deye-based inverters. REGISTER_MAP=auto picks the
# one that answers with a real battery voltage; set REGISTER_MAP=classic or
# REGISTER_MAP=sunsynk in .env to force one.
MAPS = {
    # Older / single-phase layout (Sunsynk, many Inverex units). Registers 90-194.
    "sunsynk": {
        "registers": {
            "daily_pv_kwh":   (108, 0.1,  False),
            "inv_temp_raw":   (91,  1,    False),
            "batt_voltage_v": (183, 0.01, False),
            "batt_soc_pct":   (184, 1,    False),
            "batt_power_w":   (190, 1,    True),   # + discharge, - charge
            "batt_current_a": (191, 0.01, True),   # + discharge, - charge
            "grid_voltage_v": (150, 0.1,  False),
            "grid_freq_hz":   (192, 0.01, False),
            "grid_power_w":   (169, 1,    True),   # + import, - export
            "load_power_w":   (178, 1,    False),
            "pv1_power_w":    (186, 1,    False),
            "pv2_power_w":    (187, 1,    False),
            "pv1_voltage_v":  (109, 0.1,  False),
            "pv1_current_a":  (110, 0.1,  False),
            "pv2_voltage_v":  (111, 0.1,  False),
            "pv2_current_a":  (112, 0.1,  False),
        },
        "blocks": [
            ("energy",  [108]),
            ("temp",    [91]),
            ("battery", [183, 184, 190, 191]),
            ("grid",    [150, 169, 192]),
            ("load",    [178]),
            ("pv_dc",   [109, 110, 111, 112]),
            ("pv_w",    [186, 187]),
        ],
        "probe": 183,
    },
    # Newer layout (registers 5xx-6xx), kept from the first version.
    "classic": {
        "registers": {
            "daily_pv_kwh":   (529, 0.1,  False),
            "inv_temp_raw":   (540, 1,    False),
            "batt_voltage_v": (587, 0.01, False),
            "batt_soc_pct":   (588, 1,    False),
            "batt_power_w":   (590, 1,    True),
            "batt_current_a": (591, 0.01, True),
            "grid_voltage_v": (598, 0.1,  False),
            "grid_freq_hz":   (609, 0.01, False),
            "grid_power_w":   (625, 1,    True),
            "load_power_w":   (653, 1,    False),
            "pv1_power_w":    (672, 1,    False),
            "pv2_power_w":    (673, 1,    False),
            "pv1_voltage_v":  (676, 0.1,  False),
            "pv1_current_a":  (677, 0.1,  False),
            "pv2_voltage_v":  (678, 0.1,  False),
            "pv2_current_a":  (679, 0.1,  False),
        },
        "blocks": [
            ("energy",  [529]),
            ("temp",    [540]),
            ("battery", [587, 588, 590, 591]),
            ("grid",    [598, 609, 625]),
            ("load",    [653]),
            ("pv",      [672, 673, 676, 677, 678, 679]),
        ],
        "probe": 587,
    },
}
REGISTER_MAP = _env("REGISTER_MAP", "auto").lower()
ACTIVE_MAP = REGISTER_MAP if REGISTER_MAP in MAPS else "sunsynk"
REGISTERS = MAPS[ACTIVE_MAP]["registers"]
BLOCKS = MAPS[ACTIVE_MAP]["blocks"]


def use_map(name):
    global ACTIVE_MAP, REGISTERS, BLOCKS
    ACTIVE_MAP = name
    REGISTERS = MAPS[name]["registers"]
    BLOCKS = MAPS[name]["blocks"]
    log.info("Using register layout: %s", name)


def detect_map():
    """Pick the layout whose battery-voltage register holds a plausible value."""
    if REGISTER_MAP in MAPS:
        use_map(REGISTER_MAP)
        return
    for name in ("sunsynk", "classic"):
        try:
            raw = _modbus.read_holding_registers(MAPS[name]["probe"], 1)[0]
        except Exception:  # noqa: BLE001
            continue
        if 1000 <= raw <= 12000:   # 10 V to 120 V in 0.01 V steps
            use_map(name)
            return
    log.warning("Could not tell which register layout this inverter uses; trying sunsynk")
    use_map("sunsynk")


def to_signed(value):
    """16-bit two's complement."""
    return value - 0x10000 if value >= 0x8000 else value


# ---------------------------------------------------------------------------
# Shared state
# ---------------------------------------------------------------------------
class Store:
    def __init__(self):
        self.cond = threading.Condition()
        self.seq = 0
        self.values = {name: None for name in REGISTERS}
        self.last_ok = None          # time of last successful read (any block)
        self.last_full_ok = None     # time of last read where every block worked
        self.error = None
        self.block_errors = {}
        self.fail_count = 0
        maxlen = max(10, int(HISTORY_MINUTES * 60 / POLL_INTERVAL))
        self.history = deque(maxlen=maxlen)

    def snapshot(self):
        v = self.values
        now = time.time()
        age = None if self.last_ok is None else now - self.last_ok
        online = age is not None and age <= STALE_AFTER_S and self.fail_count == 0

        def r(x, n=1):
            return None if x is None else round(x, n)

        batt_p = v["batt_power_w"]
        batt_i = v["batt_current_a"]
        if BATTERY_INVERT:
            batt_p = None if batt_p is None else -batt_p
            batt_i = None if batt_i is None else -batt_i
        grid_p = v["grid_power_w"]
        if GRID_INVERT and grid_p is not None:
            grid_p = -grid_p

        def state(p, pos, neg):
            if p is None:
                return None
            if abs(p) < DEADBAND_W:
                return "idle"
            return pos if p > 0 else neg

        pv1, pv2 = v["pv1_power_w"], v["pv2_power_w"]
        pv_total = None if pv1 is None and pv2 is None else (pv1 or 0) + (pv2 or 0)
        temp = None if v["inv_temp_raw"] is None else (v["inv_temp_raw"] - TEMP_OFFSET) / 10.0

        return {
            "status": "online" if online else "offline",
            "stale": not online,
            "age_s": r(age, 1),
            "timestamp": self.last_ok,
            "server_time": now,
            "error": self.error,
            "block_errors": dict(self.block_errors),
            "source": {"ip": INVERTER_IP, "logger_sn": LOGGER_SN},
            "pv": {
                "total_w": pv_total,
                "pv1": {"power_w": pv1, "voltage_v": r(v["pv1_voltage_v"]), "current_a": r(v["pv1_current_a"])},
                "pv2": {"power_w": pv2, "voltage_v": r(v["pv2_voltage_v"]), "current_a": r(v["pv2_current_a"])},
            },
            "battery": {
                "soc_pct": v["batt_soc_pct"],
                "voltage_v": r(v["batt_voltage_v"], 2),
                "current_a": r(batt_i, 2),
                "power_w": batt_p,
                "state": state(batt_p, "discharging", "charging"),
            },
            "grid": {
                "power_w": grid_p,
                "voltage_v": r(v["grid_voltage_v"]),
                "frequency_hz": r(v["grid_freq_hz"], 2),
                "state": state(grid_p, "importing", "exporting"),
            },
            "load": {"power_w": v["load_power_w"]},
            "inverter": {"temperature_c": r(temp)},
            "energy": {"daily_pv_kwh": r(v["daily_pv_kwh"])},
        }

    def publish(self):
        with self.cond:
            self.seq += 1
            self.cond.notify_all()


store = Store()

# ---------------------------------------------------------------------------
# Inverter polling
# ---------------------------------------------------------------------------
_io_lock = threading.Lock()   # one conversation with the logger at a time
_modbus = None


def _connect():
    global _modbus
    from pysolarmanv5 import PySolarmanV5  # imported late so the dashboard still starts without it

    _modbus = PySolarmanV5(
        INVERTER_IP, LOGGER_SN, port=LOGGER_PORT, mb_slave_id=SLAVE_ID, socket_timeout=SOCKET_TIMEOUT
    )
    log.info("Connected to logger %s (SN %s)", INVERTER_IP, LOGGER_SN)
    detect_map()


def _disconnect():
    global _modbus
    if _modbus is not None:
        try:
            _modbus.disconnect()
        except Exception:
            pass
    _modbus = None


def _read_block(addrs):
    start, end = min(addrs), max(addrs)
    regs = _modbus.read_holding_registers(start, end - start + 1)
    if len(regs) != end - start + 1:
        raise IOError("short read")
    return {a: regs[a - start] for a in addrs}


def poll_once():
    """Read every block once. Returns number of blocks that failed."""
    raw = {}
    errors = {}
    with _io_lock:
        if _modbus is None:
            _connect()
        for name, addrs in BLOCKS:
            try:
                raw.update(_read_block(addrs))
            except Exception as exc:  # noqa: BLE001 - one bad block must not stop the others
                errors[name] = f"{type(exc).__name__}: {exc}"
        if len(errors) == len(BLOCKS):
            _disconnect()  # everything failed: drop the socket and reconnect next time

    for key, (addr, scale, signed) in REGISTERS.items():
        if addr in raw:
            val = raw[addr]
            if signed:
                val = to_signed(val)
            store.values[key] = val * scale if scale != 1 else val
    store.block_errors = errors
    return len(errors), len(BLOCKS)


def poll_loop():
    backoff = POLL_INTERVAL
    while True:
        started = time.time()
        try:
            failed, total = poll_once()
            if failed < total:
                store.last_ok = time.time()
                store.fail_count = 0
                store.error = None if failed == 0 else f"{failed} of {total} register groups failed"
                if failed == 0:
                    store.last_full_ok = store.last_ok
                backoff = POLL_INTERVAL
            else:
                raise IOError("; ".join(f"{k}: {v}" for k, v in list(store.block_errors.items())[:2]))
        except Exception as exc:  # noqa: BLE001
            store.fail_count += 1
            store.error = f"Cannot reach inverter: {exc}"
            _disconnect()
            backoff = min(30.0, POLL_INTERVAL * (2 ** min(store.fail_count, 4)))
            if store.fail_count in (1, 5) or store.fail_count % 20 == 0:
                log.warning("%s (attempt %d, retry in %.0fs)", store.error, store.fail_count, backoff)

        snap = store.snapshot()
        if snap["pv"]["total_w"] is not None or snap["load"]["power_w"] is not None:
            store.history.append(
                {"t": time.time(), "solar": snap["pv"]["total_w"], "load": snap["load"]["power_w"],
                 "live": snap["status"] == "online"}
            )
        store.publish()
        time.sleep(max(0.2, backoff - (time.time() - started)))


# ---------------------------------------------------------------------------
# Web app
# ---------------------------------------------------------------------------
app = Flask(__name__)


@app.after_request
def no_cache(resp):
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")


@app.get("/api/telemetry")
def telemetry():
    return jsonify(store.snapshot())


@app.get("/api/history")
def history():
    cutoff = time.time() - HISTORY_MINUTES * 60
    return jsonify([h for h in list(store.history) if h["t"] >= cutoff])


@app.get("/api/health")
def health():
    snap = store.snapshot()
    return jsonify({"ok": True, "inverter": snap["status"], "error": snap["error"]})


@app.get("/api/raw")
def raw_registers():
    """Read raw holding registers to verify the register map: /api/raw?start=586&count=10"""
    try:
        start = int(request.args.get("start", 586))
        count = int(request.args.get("count", 10))
    except ValueError:
        return jsonify({"error": "start and count must be numbers"}), 400
    if not (0 <= start <= 65535 and 1 <= count <= 100):
        return jsonify({"error": "count must be 1-100"}), 400
    try:
        with _io_lock:
            if _modbus is None:
                _connect()
            regs = _modbus.read_holding_registers(start, count)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 502
    return jsonify({"start": start, "registers": [
        {"address": start + i, "raw": v, "signed": to_signed(v)} for i, v in enumerate(regs)]})


def _sse(event, payload):
    return f"event: {event}\ndata: {json.dumps(payload)}\n\n"


@app.get("/ws/live")
def live():
    """Server-Sent Events stream: one 'telemetry' event per poll (about every 3 s)."""
    def generate():
        last = -1
        yield "retry: 3000\n\n"
        while True:
            with store.cond:
                if store.seq == last:
                    store.cond.wait(timeout=15)
                changed = store.seq != last
                last = store.seq
            if changed:
                yield _sse("telemetry", store.snapshot())
            else:
                yield ": keepalive\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"X-Accel-Buffering": "no", "Connection": "keep-alive"})


def main():
    if LOGGER_SN == 0:
        log.warning("LOGGER_SN is not set. Copy .env.example to .env and fill it in.")
    log.info("Polling %s every %.0fs, dashboard on http://localhost:%d", INVERTER_IP, POLL_INTERVAL, PORT)
    threading.Thread(target=poll_loop, daemon=True, name="poller").start()
    app.run(host=HOST, port=PORT, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
