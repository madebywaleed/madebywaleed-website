"""LmarSys: solar inverter live monitor (Deye-based inverters).

Polls a Solarman Wi-Fi data logger over the local network (TCP 8899) with
pysolarmanv5, keeps the last known values, and serves a dashboard plus a JSON
API and a live stream.

Run:  python main.py
"""
import csv
import io
import json
import logging
import os
import sqlite3
import threading
import time
from collections import deque
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, Response, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _env(name, default, cast=str):
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return cast(raw.strip())
    except ValueError:
        logging.warning("Bad value %r for %s, using default %r", raw, name, default)
        return default


INVERTER_IP = _env("INVERTER_IP", "192.168.1.50")
LOGGER_SN = _env("LOGGER_SN", 0, int)
LOGGER_PORT = _env("LOGGER_PORT", 8899, int)
SLAVE_ID = _env("MODBUS_SLAVE_ID", 1, int)
POLL_INTERVAL = max(1.0, _env("POLL_INTERVAL", 3.0, float))
SOCKET_TIMEOUT = _env("SOCKET_TIMEOUT", 5, float)
HOST = _env("HOST", "0.0.0.0")
PORT = _env("PORT", 8000, int)
HISTORY_MINUTES = _env("HISTORY_MINUTES", 60, int)
DB_PATH = _env("DB_PATH", str(BASE_DIR / "lmarsys.db"))
BATTERY_INVERT = _env("BATTERY_POWER_INVERT", 0, int) == 1
GRID_INVERT = _env("GRID_POWER_INVERT", 0, int) == 1
DEADBAND_W = _env("IDLE_DEADBAND_W", 20, float)
TEMP_OFFSET = _env("TEMP_OFFSET", 1000, int)
# Seconds without a good read before the dashboard calls the data stale
STALE_AFTER_S = max(10.0, POLL_INTERVAL * 3)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("lmarsys")

# ---------------------------------------------------------------------------
# Register map (Modbus holding registers, function 0x03).
# EDIT HERE if your firmware uses different addresses. Use /api/raw to check.
#   name: (address, scale, signed)
# ---------------------------------------------------------------------------
# Two known register layouts for Deye-based inverters. REGISTER_MAP=auto picks the
# one that answers with a real battery voltage; set REGISTER_MAP=classic or
# REGISTER_MAP=sunsynk in .env to force one.
MAPS = {
    # Older / single-phase layout (Sunsynk, many Inverex units). Registers 90-194.
    "sunsynk": {
        "registers": {
            "daily_pv_kwh":   (108, 0.1,  False),
            "inv_temp_raw":   (91,  1,    False),
            "batt_voltage_v": (183, 0.01, False),
            "batt_soc_pct":   (184, 1,    False),
            "batt_power_w":   (190, 1,    True),   # + discharge, - charge
            "batt_current_a": (191, 0.01, True),   # + discharge, - charge
            "grid_voltage_v": (150, 0.1,  False),
            "grid_freq_hz":   (192, 0.01, False),
            "grid_power_w":   (169, 1,    True),   # + import, - export
            "load_power_w":   (178, 1,    False),
            "pv1_power_w":    (186, 1,    False),
            "pv2_power_w":    (187, 1,    False),
            "pv1_voltage_v":  (109, 0.1,  False),
            "pv1_current_a":  (110, 0.1,  False),
            "pv2_voltage_v":  (111, 0.1,  False),
            "pv2_current_a":  (112, 0.1,  False),
        },
        "blocks": [
            ("energy",  [108]),
            ("temp",    [91]),
            ("battery", [183, 184, 190, 191]),
            ("grid",    [150, 169, 192]),
            ("load",    [178]),
            ("pv_dc",   [109, 110, 111, 112]),
            ("pv_w",    [186, 187]),
        ],
        "probe": 183,
    },
    # Newer layout (registers 5xx-6xx), kept from the first version.
    "classic": {
        "registers": {
            "daily_pv_kwh":   (529, 0.1,  False),
            "inv_temp_raw":   (540, 1,    False),
            "batt_voltage_v": (587, 0.01, False),
            "batt_soc_pct":   (588, 1,    False),
            "batt_power_w":   (590, 1,    True),
            "batt_current_a": (591, 0.01, True),
            "grid_voltage_v": (598, 0.1,  False),
            "grid_freq_hz":   (609, 0.01, False),
            "grid_power_w":   (625, 1,    True),
            "load_power_w":   (653, 1,    False),
            "pv1_power_w":    (672, 1,    False),
            "pv2_power_w":    (673, 1,    False),
            "pv1_voltage_v":  (676, 0.1,  False),
            "pv1_current_a":  (677, 0.1,  False),
            "pv2_voltage_v":  (678, 0.1,  False),
            "pv2_current_a":  (679, 0.1,  False),
        },
        "blocks": [
            ("energy",  [529]),
            ("temp",    [540]),
            ("battery", [587, 588, 590, 591]),
            ("grid",    [598, 609, 625]),
            ("load",    [653]),
            ("pv",      [672, 673, 676, 677, 678, 679]),
        ],
        "probe": 587,
    },
}
REGISTER_MAP = _env("REGISTER_MAP", "auto").lower()
ACTIVE_MAP = REGISTER_MAP if REGISTER_MAP in MAPS else "sunsynk"
REGISTERS = MAPS[ACTIVE_MAP]["registers"]
BLOCKS = MAPS[ACTIVE_MAP]["blocks"]


def use_map(name):
    global ACTIVE_MAP, REGISTERS, BLOCKS
    ACTIVE_MAP = name
    REGISTERS = MAPS[name]["registers"]
    BLOCKS = MAPS[name]["blocks"]
    log.info("Using register layout: %s", name)


def detect_map():
    """Pick the layout whose battery-voltage register holds a plausible value."""
    if REGISTER_MAP in MAPS:
        use_map(REGISTER_MAP)
        return
    for name in ("sunsynk", "classic"):
        try:
            raw = _modbus.read_holding_registers(MAPS[name]["probe"], 1)[0]
        except Exception:  # noqa: BLE001
            continue
        if 1000 <= raw <= 12000:   # 10 V to 120 V in 0.01 V steps
            use_map(name)
            return
    log.warning("Could not tell which register layout this inverter uses; trying sunsynk")
    use_map("sunsynk")


def to_signed(value):
    """16-bit two's complement."""
    return value - 0x10000 if value >= 0x8000 else value


# ---------------------------------------------------------------------------
# Shared state
# ---------------------------------------------------------------------------
class Store:
    def __init__(self):
        self.cond = threading.Condition()
        self.seq = 0
        self.values = {name: None for name in REGISTERS}
        self.last_ok = None          # time of last successful read (any block)
        self.last_full_ok = None     # time of last read where every block worked
        self.error = None
        self.block_errors = {}
        self.fail_count = 0
        maxlen = max(10, int(HISTORY_MINUTES * 60 / POLL_INTERVAL))
        self.history = deque(maxlen=maxlen)

    def snapshot(self):
        v = self.values
        now = time.time()
        age = None if self.last_ok is None else now - self.last_ok
        online = age is not None and age <= STALE_AFTER_S and self.fail_count == 0

        def r(x, n=1):
            return None if x is None else round(x, n)

        batt_p = v["batt_power_w"]
        batt_i = v["batt_current_a"]
        if BATTERY_INVERT:
            batt_p = None if batt_p is None else -batt_p
            batt_i = None if batt_i is None else -batt_i
        grid_p = v["grid_power_w"]
        if GRID_INVERT and grid_p is not None:
            grid_p = -grid_p

        def state(p, pos, neg):
            if p is None:
                return None
            if abs(p) < DEADBAND_W:
                return "idle"
            return pos if p > 0 else neg

        pv1, pv2 = v["pv1_power_w"], v["pv2_power_w"]
        pv_total = None if pv1 is None and pv2 is None else (pv1 or 0) + (pv2 or 0)
        temp = None if v["inv_temp_raw"] is None else (v["inv_temp_raw"] - TEMP_OFFSET) / 10.0

        return {
            "status": "online" if online else "offline",
            "stale": not online,
            "age_s": r(age, 1),
            "timestamp": self.last_ok,
            "server_time": now,
            "error": self.error,
            "block_errors": dict(self.block_errors),
            "source": {"ip": INVERTER_IP, "logger_sn": LOGGER_SN},
            "pv": {
                "total_w": pv_total,
                "pv1": {"power_w": pv1, "voltage_v": r(v["pv1_voltage_v"]), "current_a": r(v["pv1_current_a"])},
                "pv2": {"power_w": pv2, "voltage_v": r(v["pv2_voltage_v"]), "current_a": r(v["pv2_current_a"])},
            },
            "battery": {
                "soc_pct": v["batt_soc_pct"],
                "voltage_v": r(v["batt_voltage_v"], 2),
                "current_a": r(batt_i, 2),
                "power_w": batt_p,
                "state": state(batt_p, "discharging", "charging"),
            },
            "grid": {
                "power_w": grid_p,
                "voltage_v": r(v["grid_voltage_v"]),
                "frequency_hz": r(v["grid_freq_hz"], 2),
                "state": state(grid_p, "importing", "exporting"),
            },
            "load": {"power_w": v["load_power_w"]},
            "inverter": {"temperature_c": r(temp)},
            "energy": {"daily_pv_kwh": r(v["daily_pv_kwh"])},
        }

    def publish(self):
        with self.cond:
            self.seq += 1
            self.cond.notify_all()


store = Store()

# ---------------------------------------------------------------------------
# Inverter polling
# ---------------------------------------------------------------------------
_io_lock = threading.Lock()   # one conversation with the logger at a time
_modbus = None


def _connect():
    global _modbus
    from pysolarmanv5 import PySolarmanV5  # imported late so the dashboard still starts without it

    _modbus = PySolarmanV5(
        INVERTER_IP, LOGGER_SN, port=LOGGER_PORT, mb_slave_id=SLAVE_ID, socket_timeout=SOCKET_TIMEOUT
    )
    log.info("Connected to logger %s (SN %s)", INVERTER_IP, LOGGER_SN)
    detect_map()


def _disconnect():
    global _modbus
    if _modbus is not None:
        try:
            _modbus.disconnect()
        except Exception:
            pass
    _modbus = None


def _read_block(addrs):
    start, end = min(addrs), max(addrs)
    regs = _modbus.read_holding_registers(start, end - start + 1)
    if len(regs) != end - start + 1:
        raise IOError("short read")
    return {a: regs[a - start] for a in addrs}


def poll_once():
    """Read every block once. Returns number of blocks that failed."""
    raw = {}
    errors = {}
    with _io_lock:
        if _modbus is None:
            _connect()
        for name, addrs in BLOCKS:
            try:
                raw.update(_read_block(addrs))
            except Exception as exc:  # noqa: BLE001 - one bad block must not stop the others
                errors[name] = f"{type(exc).__name__}: {exc}"
        if len(errors) == len(BLOCKS):
            _disconnect()  # everything failed: drop the socket and reconnect next time

    for key, (addr, scale, signed) in REGISTERS.items():
        if addr in raw:
            val = raw[addr]
            if signed:
                val = to_signed(val)
            store.values[key] = val * scale if scale != 1 else val
    store.block_errors = errors
    return len(errors), len(BLOCKS)


def poll_loop():
    backoff = POLL_INTERVAL
    while True:
        started = time.time()
        try:
            failed, total = poll_once()
            if failed < total:
                store.last_ok = time.time()
                store.fail_count = 0
                store.error = None if failed == 0 else f"{failed} of {total} register groups failed"
                if failed == 0:
                    store.last_full_ok = store.last_ok
                backoff = POLL_INTERVAL
            else:
                raise IOError("; ".join(f"{k}: {v}" for k, v in list(store.block_errors.items())[:2]))
        except Exception as exc:  # noqa: BLE001
            store.fail_count += 1
            store.error = f"Cannot reach inverter: {exc}"
            _disconnect()
            backoff = min(30.0, POLL_INTERVAL * (2 ** min(store.fail_count, 4)))
            if store.fail_count in (1, 5) or store.fail_count % 20 == 0:
                log.warning("%s (attempt %d, retry in %.0fs)", store.error, store.fail_count, backoff)

        snap = store.snapshot()
        if snap["pv"]["total_w"] is not None or snap["load"]["power_w"] is not None:
            store.history.append(
                {"t": time.time(), "solar": snap["pv"]["total_w"], "load": snap["load"]["power_w"],
                 "live": snap["status"] == "online"}
            )
        try:
            record_sample(snap)
        except Exception as exc:  # noqa: BLE001
            log.warning("Could not save history: %s", exc)
        store.publish()
        time.sleep(max(0.2, backoff - (time.time() - started)))



# ---------------------------------------------------------------------------
# Long-term history (SQLite, one row per minute, kept forever)
# ---------------------------------------------------------------------------
_db = None
_db_lock = threading.Lock()
_last_rec = None   # time of the previous recorded sample


def db_open():
    global _db
    _db = sqlite3.connect(DB_PATH, check_same_thread=False)
    _db.execute("PRAGMA journal_mode=WAL")
    _db.execute("PRAGMA synchronous=NORMAL")
    _db.execute(
        """CREATE TABLE IF NOT EXISTS minute (
            ts INTEGER PRIMARY KEY, n INTEGER, secs REAL,
            solar REAL, load REAL, grid REAL, batt REAL, soc REAL, vbatt REAL, temp REAL,
            solar_wh REAL, load_wh REAL, imp_wh REAL, exp_wh REAL, chg_wh REAL, dis_wh REAL,
            solar_max REAL, load_max REAL)"""
    )
    _db.commit()
    log.info("History database: %s", DB_PATH)


def record_sample(snap):
    """Add one good reading to the current minute's row."""
    global _last_rec
    if _db is None or snap["status"] != "online":
        return
    pv, load = snap["pv"]["total_w"], snap["load"]["power_w"]
    if pv is None or load is None:
        return
    now = time.time()
    dt = POLL_INTERVAL if _last_rec is None else min(now - _last_rec, max(10.0, POLL_INTERVAL * 3))
    _last_rec = now
    grid = snap["grid"]["power_w"] or 0.0        # + import, - export
    batt = snap["battery"]["power_w"] or 0.0     # + discharge, - charge
    soc = snap["battery"]["soc_pct"] or 0.0
    vbatt = snap["battery"]["voltage_v"] or 0.0
    temp = snap["inverter"]["temperature_c"] or 0.0
    k = dt / 3600.0
    row = (int(now // 60 * 60), 1, dt, pv, load, grid, batt, soc, vbatt, temp,
           pv * k, load * k, max(grid, 0) * k, max(-grid, 0) * k, max(-batt, 0) * k, max(batt, 0) * k, pv, load)
    with _db_lock:
        _db.execute(
            """INSERT INTO minute VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(ts) DO UPDATE SET n=n+1, secs=secs+excluded.secs,
                 solar=solar+excluded.solar, load=load+excluded.load, grid=grid+excluded.grid,
                 batt=batt+excluded.batt, soc=soc+excluded.soc, vbatt=vbatt+excluded.vbatt,
                 temp=temp+excluded.temp, solar_wh=solar_wh+excluded.solar_wh,
                 load_wh=load_wh+excluded.load_wh, imp_wh=imp_wh+excluded.imp_wh,
                 exp_wh=exp_wh+excluded.exp_wh, chg_wh=chg_wh+excluded.chg_wh,
                 dis_wh=dis_wh+excluded.dis_wh, solar_max=MAX(solar_max, excluded.solar_max),
                 load_max=MAX(load_max, excluded.load_max)""", row)
        _db.commit()


# range name -> (seconds back, chart bucket seconds, energy-bar bucket seconds or 0)
RANGES = {
    "60m": (3600, 60, 0),
    "1d": (86400, 300, 3600),
    "1w": (7 * 86400, 1800, 86400),
    "1m": (30 * 86400, 7200, 86400),
    "1y": (365 * 86400, 86400, 7 * 86400),
    "all": None,
}
_NICE = [60, 300, 900, 1800, 3600, 7200, 21600, 86400, 7 * 86400, 30 * 86400]


def _pick_bucket(span, max_points, minimum=60):
    for b in _NICE:
        if b >= minimum and span / b <= max_points:
            return b
    return _NICE[-1]


def _bucket_rows(start, bucket, off):
    with _db_lock:
        return _db.execute(
            """SELECT ((ts + ?) / ?) * ? - ? AS b, SUM(n), SUM(solar), SUM(load), SUM(grid), SUM(batt),
                      SUM(soc), SUM(vbatt), SUM(solar_wh), SUM(load_wh), SUM(imp_wh), SUM(exp_wh),
                      SUM(chg_wh), SUM(dis_wh), MAX(solar_max), MAX(load_max), SUM(secs)
               FROM minute WHERE ts >= ? GROUP BY b ORDER BY b""",
            (off, bucket, bucket, off, start)).fetchall()


def query_range(name):
    now = int(time.time())
    off = time.localtime(now).tm_gmtoff or 0
    if name == "all":
        with _db_lock:
            first = _db.execute("SELECT MIN(ts) FROM minute").fetchone()[0]
        start = first if first is not None else now - 3600
        span = max(now - start, 3600)
        bucket, ebucket = _pick_bucket(span, 400), _pick_bucket(span, 60, 3600)
    else:
        span, bucket, ebucket = RANGES[name]
        start = now - span
    rows = _bucket_rows(start, bucket, off)
    points = []
    for r in rows:
        n = r[1] or 1
        points.append({"t": r[0], "solar": r[2] / n, "load": r[3] / n, "grid": r[4] / n, "batt": r[5] / n,
                       "soc": r[6] / n, "solar_max": r[14], "load_max": r[15]})
    energy = []
    if ebucket:
        for r in _bucket_rows(start, ebucket, off):
            energy.append({"t": r[0], "solar": r[8] / 1000, "load": r[9] / 1000, "imp": r[10] / 1000,
                           "exp": r[11] / 1000, "chg": r[12] / 1000, "dis": r[13] / 1000})
    tot = {k: 0.0 for k in ("solar", "load", "imp", "exp", "chg", "dis")}
    secs = 0.0
    peak_s = peak_l = 0.0
    for r in rows:
        tot["solar"] += r[8] / 1000; tot["load"] += r[9] / 1000; tot["imp"] += r[10] / 1000
        tot["exp"] += r[11] / 1000; tot["chg"] += r[12] / 1000; tot["dis"] += r[13] / 1000
        secs += r[16] or 0
        peak_s = max(peak_s, r[14] or 0); peak_l = max(peak_l, r[15] or 0)
    tot["self_sufficiency_pct"] = None if tot["load"] <= 0 else round(max(0.0, min(100.0, (tot["load"] - tot["imp"]) / tot["load"] * 100)), 1)
    tot["solar_used_pct"] = None if tot["solar"] <= 0 else round(max(0.0, min(100.0, (tot["solar"] - tot["exp"]) / tot["solar"] * 100)), 1)
    tot["peak_solar_w"], tot["peak_load_w"] = peak_s, peak_l
    tot["coverage_pct"] = round(min(100.0, secs / max(now - start, 1) * 100), 1)
    return {"range": name, "start": start, "end": now, "bucket_s": bucket, "energy_bucket_s": ebucket,
            "points": points, "energy": energy, "totals": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in tot.items()}}

# ---------------------------------------------------------------------------
# Web app
# ---------------------------------------------------------------------------
app = Flask(__name__)


@app.after_request
def no_cache(resp):
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")


@app.get("/favicon.ico")
def favicon():
    return Response(status=204)


@app.get("/setup.html")
def setup_page():
    return send_from_directory(BASE_DIR, "setup.html")


@app.get("/api/config")
def api_config():
    return jsonify({"configured": True})


@app.get("/analytics.js")
def analytics_js():
    return send_from_directory(BASE_DIR, "analytics.js")


@app.get("/api/telemetry")
def telemetry():
    return jsonify(store.snapshot())


@app.get("/api/history")
def history():
    cutoff = time.time() - HISTORY_MINUTES * 60
    return jsonify([h for h in list(store.history) if h["t"] >= cutoff])


@app.get("/api/stats")
def stats():
    name = request.args.get("range", "1d")
    if name not in RANGES:
        return jsonify({"error": "range must be one of " + ", ".join(RANGES)}), 400
    return jsonify(query_range(name))


@app.get("/api/export.csv")
def export_csv():
    name = request.args.get("range", "1d")
    if name not in RANGES:
        return jsonify({"error": "range must be one of " + ", ".join(RANGES)}), 400
    data = query_range(name)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["time", "solar_w", "home_w", "grid_w(+import)", "battery_w(+discharge)", "battery_pct"])
    for p in data["points"]:
        w.writerow([time.strftime("%Y-%m-%d %H:%M", time.localtime(p["t"])), round(p["solar"]), round(p["load"]),
                    round(p["grid"]), round(p["batt"]), round(p["soc"], 1)])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=lmarsys-{name}.csv"})


@app.get("/api/health")
def health():
    snap = store.snapshot()
    return jsonify({"ok": True, "inverter": snap["status"], "error": snap["error"]})


@app.get("/api/raw")
def raw_registers():
    """Read raw holding registers to verify the register map: /api/raw?start=586&count=10"""
    try:
        start = int(request.args.get("start", 586))
        count = int(request.args.get("count", 10))
    except ValueError:
        return jsonify({"error": "start and count must be numbers"}), 400
    if not (0 <= start <= 65535 and 1 <= count <= 100):
        return jsonify({"error": "count must be 1-100"}), 400
    try:
        with _io_lock:
            if _modbus is None:
                _connect()
            regs = _modbus.read_holding_registers(start, count)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 502
    return jsonify({"start": start, "registers": [
        {"address": start + i, "raw": v, "signed": to_signed(v)} for i, v in enumerate(regs)]})


def _sse(event, payload):
    return f"event: {event}\ndata: {json.dumps(payload)}\n\n"


@app.get("/ws/live")
def live():
    """Server-Sent Events stream: one 'telemetry' event per poll (about every 3 s)."""
    def generate():
        last = -1
        yield "retry: 3000\n\n"
        while True:
            with store.cond:
                if store.seq == last:
                    store.cond.wait(timeout=15)
                changed = store.seq != last
                last = store.seq
            if changed:
                yield _sse("telemetry", store.snapshot())
            else:
                yield ": keepalive\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"X-Accel-Buffering": "no", "Connection": "keep-alive"})


def main():
    if LOGGER_SN == 0:
        log.warning("LOGGER_SN is not set. Copy .env.example to .env and fill it in.")
    log.info("Polling %s every %.0fs, dashboard on http://localhost:%d", INVERTER_IP, POLL_INTERVAL, PORT)
    db_open()
    threading.Thread(target=poll_loop, daemon=True, name="poller").start()
    app.run(host=HOST, port=PORT, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
