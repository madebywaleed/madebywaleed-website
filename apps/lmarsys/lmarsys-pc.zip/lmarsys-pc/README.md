# LmarSys (PC version)

Live solar dashboard by Made by Waleed for Deye-based hybrid inverters (Inverex, Deye, Sunsynk) with a Solarman Wi-Fi logger, read over your local network (TCP 8899). No cloud and no account needed.

This is an early version. It has only been tested with a simulated logger, so check the numbers against your inverter screen (see below). Not affiliated with Inverex, Deye, Sunsynk or Solarman.

## Files
```
lmarsys-pc/
  main.py            Flask backend: poller, /api/telemetry, /ws/live, /api/history, /api/raw
  index.html         Dashboard (HTML + CSS + vanilla JS, Chart.js from CDN)
  requirements.txt   flask, python-dotenv, pysolarmanv5
  .env.example       settings template
  README.md
```

## Install and run

Windows (PowerShell):
```powershell
cd lmarsys-pc
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
notepad .env
python main.py
```

Linux / macOS:
```bash
cd lmarsys-pc
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python main.py
```

Open http://localhost:8000 (or http://<this-computer-ip>:8000 from your phone on the same Wi-Fi).

If PowerShell blocks the activate script, run `Set-ExecutionPolicy -Scope Process Bypass` first.

## Settings (.env)
- `INVERTER_IP`: the logger's IP address. Find it in your router's device list, then reserve it so it does not change.
- `LOGGER_SN`: the logger serial number (sticker on the logger, or in the Solarman app). It is not the inverter serial.
- `POLL_INTERVAL`: seconds between reads (default 3).

## Try the dashboard without the inverter
Click **Demo mode** (top right). It shows simulated data. Untick it to return to live data.

## Check that the registers match your unit (do this first)
Inverter firmware differs between models, so confirm the numbers against what the inverter screen or Solarman app shows. With the server running, open these in a browser:
```
http://localhost:8000/api/telemetry              decoded values
http://localhost:8000/api/raw?start=586&count=12  raw registers 586-597
http://localhost:8000/api/raw?start=596&count=6   raw registers 596-601
```
If a value is wrong, change the address or scale in the `REGISTERS` table at the top of `main.py`. Two settings in `.env` cover the usual differences:
- `BATTERY_POWER_INVERT=1` / `GRID_POWER_INVERT=1` flip the charge/discharge and import/export direction.
- `TEMP_OFFSET=0` if the temperature reads about 100 degrees too high.

## Register map used
| Value | Register | Scale |
|---|---|---|
| Daily PV generation | 529 | 0.1 kWh |
| Inverter temperature | 540 | (raw - 1000) / 10 °C |
| Battery voltage | 587 | 0.01 V |
| Battery SOC | 588 | 1 % |
| Battery power (signed) | 590 | 1 W, + discharge, - charge |
| Battery current (signed) | 591 | 0.01 A |
| Grid voltage | 598 | 0.1 V |
| Grid frequency | 609 | 0.01 Hz |
| Grid power (signed) | 625 | 1 W, + import, - export |
| Load power | 653 | 1 W |
| PV1 / PV2 power | 672 / 673 | 1 W |
| PV1 voltage / current | 676 / 677 | 0.1 V / 0.1 A |
| PV2 voltage / current | 678 / 679 | 0.1 V / 0.1 A |

## Troubleshooting
- **Offline badge**: check `INVERTER_IP` and `LOGGER_SN`, and that the PC is on the same network. The logger accepts only a few connections at once, so close other tools that talk to it directly.
- **Stays on "Reconnecting"**: the browser cannot reach `main.py`. Check it is running and the port is not blocked by a firewall.
- **Chart is empty**: the Chart.js CDN needs internet on the device that opens the page. The rest of the dashboard works without it.
